main()
{
	int a, b, c, x, y;
	a = b + c;
}

